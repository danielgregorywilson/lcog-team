# lcog-hr


# Run the backend locally
Activate the virtual environment
`source env/bin/activate` 
Start the server
`./manage.py runserver`


# Run the frontend locally
`cd frontend`
`quasar dev`


# Deploy backend
`eb deploy --profile lcog`


# Deploy frontend
`cd frontend`
`quasar build`
Navidate to 