<template>
  <q-page class="row items-center justify-evenly">
    <h1>Time off requests</h1>
  </q-page>
</template>

<script lang="ts">
import { Component, Vue } from 'vue-property-decorator'

@Component
export default class TimeOffRequests extends Vue{}
</script>
